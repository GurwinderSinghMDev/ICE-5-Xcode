package com.example.mdev1001_m2023_ice6_android;

public interface CustomClickListener {
    void onItemClick(int position, int type);
}